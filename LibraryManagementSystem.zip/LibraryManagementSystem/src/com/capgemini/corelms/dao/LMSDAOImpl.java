package com.capgemini.corelms.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.core.lms.exception.LMSException;

public class LMSDAOImpl implements LMSDAO {
	Map<Integer,Book> books = new HashMap();
	
	private int bookIdvalue = 1000;
	
	public int generateBookId()
	{
		return ++bookIdvalue;
	}
	
//	///generate rand from 1 to 10000
//	public int generateBookIdRND()
//	{
//		double rndDouble = Math.random();
//		
//		return (int)(rndDouble*10000);
//	}

	@Override
	public int addBook(Book book) throws LMSException {
		// TODO Auto-generated method stub
		book.setId(generateBookId());
		
		
		//add book object as value and its id as key
		
		books.put(book.getId(), book);
		//returns books generated id
		
		return book.getId();
	}

	@Override
	public Book getBook(int bookId) throws LMSException {
		// TODO Auto-generated method stub
		Book book = books.get(bookId);
		
		if
		
		
		return null;
	}

	@Override
	public void updateBook(Book book) throws LMSException {
		if(books.containsKey((book.getId()), false)
		
		
		// update if key exists else add
		books.put(book.getId(), book);

	}

	@Override
	public Book removeBook(int bookId) throws LMSException {
		// TODO Auto-generated method stub
		Book book = books.remove(bookId);
		
		if(book==null)
		     throw new LMSException("Remove Failed as no book Fount with id"+ bookId);
		
		return book;
	}

	@Override
	public List<Book> getAllBooks() throws LMSException {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void 

}
