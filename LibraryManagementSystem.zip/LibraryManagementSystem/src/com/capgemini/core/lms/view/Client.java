package com.capgemini.core.lms.view;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.corelms.dao.LMSDAO;
import com.capgemini.corelms.dao.LMSDAOImpl;

public class Client 
{
    public static void main(String[] args) {
		LMSDAO lmsdao = new LMSDAOImpl();
		
		
		//add book
		
		Book book1= new Book("BasicJava","Amit",1200);
		Book book2 = new Book("LearnINGphp","Ravi",1300);
		
		int book1Id = 0;
		int book2Id = 0;
		
		try
		{
			book1Id = lmsdao.addBook(book1);
			book2Id = lmsdao.addBook(book2);
			
			System.out.println("Book1 id : " + book1Id);
			System.out.println("Book2 id : " + book2Id);
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			Book book3 = lmsdao.getBook(book1Id);
			Book book4 = lmsdao.getBook(book2Id);
		    System.out.println(book3);
		    System.out.println(book4);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
